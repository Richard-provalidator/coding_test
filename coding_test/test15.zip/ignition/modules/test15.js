const { buildModule } = require("@nomicfoundation/hardhat-ignition/modules");

module.exports = buildModule("First", (m) => {
  const test15 = m.contract("A");
  return { test15 };
});
